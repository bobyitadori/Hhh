const puppeteer = require('puppeteer');

async function loginGitHub(browser, credentials) {
  const page = await browser.newPage();
  
  try {
    await page.goto('https://github.com/login');
    await page.type('#login_field', credentials.username);
    await page.type('#password', credentials.password);
    await page.click('input[type="submit"]');
    await page.waitForNavigation();
    return page;
  } catch (error) {
    console.error('GitHub login failed:', error.message);
    throw error;
  }
}

module.exports = { loginGitHub };