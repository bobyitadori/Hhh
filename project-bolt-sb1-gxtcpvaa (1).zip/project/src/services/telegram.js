const TelegramBot = require('node-telegram-bot-api');

async function sendScreenshot(config, screenshot) {
  const bot = new TelegramBot(config.telegram.botToken, { polling: false });
  
  try {
    await bot.sendPhoto(config.telegram.chatId, screenshot, {
      caption: 'Automated Screenshot'
    });
  } catch (error) {
    console.error('Failed to send Telegram message:', error.message);
    throw error;
  }
}

module.exports = { sendScreenshot };