const SELECTOR_ALTERNATIVES = {
  // GitHub selectors
  '#login_field': ['input[name="login"]', '#user_login'],
  '#password': ['input[name="password"]', '#user_password'],
  'input[type="submit"]': ['input[name="commit"]', 'button[type="submit"]'],
  
  // CS50 selectors
  '.github-login-button': [
    'button[aria-label*="GitHub"]',
    'button:has-text("Sign in with GitHub")',
    '[data-testid="github-button"]'
  ],
  '.nodejs-option': [
    '[data-value="nodejs"]',
    'button:has-text("Node.js")',
    '[aria-label*="Node.js"]'
  ]
};

async function verifySelector(page, selector) {
  try {
    const element = await page.$(selector);
    if (element) {
      console.log(`✅ Selector found: ${selector}`);
      return selector;
    }
    
    console.log(`❌ Failed selector: ${selector}`);
    
    // Try alternatives
    const alternatives = SELECTOR_ALTERNATIVES[selector] || [];
    for (const altSelector of alternatives) {
      console.log(`🔄 Trying alternative: ${altSelector}`);
      const altElement = await page.$(altSelector);
      if (altElement) {
        console.log(`✅ Alternative selector works: ${altSelector}`);
        return altSelector;
      }
      console.log(`❌ Alternative failed: ${altSelector}`);
    }
    
    throw new Error(`No working selector found for: ${selector}`);
  } catch (error) {
    throw new Error(`Selector verification failed: ${error.message}`);
  }
}

module.exports = { verifySelector };