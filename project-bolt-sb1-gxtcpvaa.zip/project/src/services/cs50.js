async function loginCS50Dev(page) {
  try {
    await page.goto('https://cs50.dev');
    await page.waitForSelector('.github-login-button');
    await page.click('.github-login-button');
    
    // Wait for Node.js option and select it
    await page.waitForSelector('.nodejs-option');
    await page.click('.nodejs-option');
  } catch (error) {
    console.error('CS50 login failed:', error.message);
    throw error;
  }
}

module.exports = { loginCS50Dev };