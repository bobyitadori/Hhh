require('dotenv').config();

const config = {
  github: {
    username: process.env.GITHUB_USERNAME,
    password: process.env.GITHUB_PASSWORD
  },
  telegram: {
    botToken: process.env.TELEGRAM_BOT_TOKEN,
    chatId: process.env.TELEGRAM_CHAT_ID
  }
};

module.exports = config;