const puppeteer = require('puppeteer');
const { verifySelector } = require('../utils/selectorChecker');

async function loginGitHub(browser, credentials) {
  const page = await browser.newPage();
  
  try {
    await page.goto('https://github.com/login');
    
    // Verify and get working selectors
    const usernameSelector = await verifySelector(page, '#login_field');
    const passwordSelector = await verifySelector(page, '#password');
    const submitSelector = await verifySelector(page, 'input[type="submit"]');
    
    // Use verified selectors
    await page.type(usernameSelector, credentials.username);
    await page.type(passwordSelector, credentials.password);
    await page.click(submitSelector);
    
    await page.waitForNavigation();
    return page;
  } catch (error) {
    console.error('GitHub login failed:', error.message);
    throw error;
  }
}