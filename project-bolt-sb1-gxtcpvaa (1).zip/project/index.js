const puppeteer = require('puppeteer');
const config = require('./src/config');
const { loginGitHub } = require('./src/services/github');
const { sendScreenshot } = require('./src/services/telegram');
const { loginCS50Dev } = require('./src/services/cs50');

async function takeScreenshot(page) {
  return await page.screenshot({ 
    fullPage: true 
  });
}

async function main() {
  let browser;
  
  try {
    browser = await puppeteer.launch({ 
      headless: true,
      args: ['--no-sandbox']
    });

    const page = await loginGitHub(browser, config.github);
    const screenshot = await takeScreenshot(page);
    await sendScreenshot(config, screenshot);
    await loginCS50Dev(page);
    
  } catch (error) {
    console.error('Application error:', error.message);
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}

if (require.main === module) {
  main();
}

module.exports = { main };